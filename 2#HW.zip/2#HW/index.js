//HOME ****

//
// #1
// function addArrLength(lng) {
//   const myArr = [];
//   for (let i = 0; i < lng; i++) {
//     myArr.push(1);
//   }

//   console.log(myArr.length);
// }
// addArrLength(3);

// #2

// function numToSquare(myArr) {
//   if (Array.isArray(myArr)) {
//     console.log(myArr);
//     function toSquar(index, item) {
//       console.log(index, item);
//       return Math.pow(index, 2);
//     }
//     const newArr = myArr.map(toSquar);
//     console.log(newArr);
//   }
// }

// numToSquare([1, 2, 3]);
// #3

// function checkArr(myArr) {
//   if (Array.isArray(myArr)) {
//     let sum = 0;

//     for (let i = 0; i < myArr.length; i++) {
//       sum += myArr[i];
//     }
//     if (sum > 100) {
//       console.log(true);
//     } else {
//       console.log(false);
//     }
//   }
// }
// checkArr([2, 3, 2, 3, 50, 80]);

// #4

// function checkEvenNumber(myArr, mlpt) {
//   if (Array.isArray(myArr)) {
//     function checkEven(item, index) {
//       console.log(index, item);
//       if (item % 2 == 0) {
//         return item + mlpt;
//       } else {
//         return item;
//       }
//     }
//   }
//   const newArr = myArr.map(checkEven);
//   console.log(newArr);
// }
// checkEvenNumber([2, 3, 4], 2);

// #5
// function reverseArray(myArr) {
//   if (Array.isArray(myArr)) {
//     myArr.reverse();
//     console.log(myArr);
//   }
// }
// reverseArray([2, 3, 1]);

// #6

// function cloneArr(myArr) {
//   if (Array.isArray(myArr)) {
//     const clonedArr = JSON.parse(JSON.stringify(myArr));
//     console.log(clonedArr);
//   }
// }
// cloneArr([2, 4, 6]);

//#7
// function checkNumber(myArr) {
//   const highiest = Math.max(...myArr);
//   const lowerst = Math.min(...myArr);

//   function check() {
//     if (lowerst + highiest >= 100) {
//       return true;
//     } else {
//       return false;
//     }
//   }
//   console.log(check());
// }
// checkNumber([500, 800, 201]);

// #8
// const users = ["Yu", "Mike", "Anna", "Wan"];
// const count = [100, 200, 400, 60];
// const name = "Mike";
// const paymant = 10;
// function payTheBill() {
//   function checkUser(index) {
//     return index === "Wan";
//   }
//   let index = users.findIndex(checkUser);
//   function checkCount() {
//     while (count[index] >= paymant) {
//       count[index] = count[index] - paymant;
//     }
//     if (count[index] <= paymant) {
//       count[index] = -1;
//     }
//     console.log(count[index]);
//   }
//   checkCount();
// }
// payTheBill();
//#9
// function checkArr(arr, n) {
//   if (arr.length >= n) {
//     const slicedArr = arr.slice(0, n);
//     return ([...rest] = slicedArr);
//   } else {
//     return false;
//   }
// }
// console.log(checkArr([2, 3, 5], 2));
// // 10

// function checkNumber(arr, n) {
//   function checkArr(index) {
//     if (index === n) {
//       return true;
//     } else {
//       return false;
//     }
//   }
//   const item = arr.map(checkArr);
// }
// checkNumber([2, 3, 7], 7);

// //11
let arr = [2, 3, 4, 2];

let uniqueIndex = [];
arr.forEach((c) => {
  if (!uniqueIndex.includes(c)) {
    uniqueIndex.push(c);
  }
});

console.log(uniqueIndex);
